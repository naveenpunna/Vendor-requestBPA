sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ivp.vendor.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);